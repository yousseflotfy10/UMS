-- UMS Sprint 2 safe database update
-- Run this in Supabase SQL Editor after the main room seed file.

-- Course validation support: optional schedule and prerequisites.
alter table public.courses
  add column if not exists prerequisite_codes text,
  add column if not exists schedule_day text,
  add column if not exists schedule_time_slot text;

create index if not exists courses_code_idx on public.courses (code);
create index if not exists courses_department_idx on public.courses (department);
create index if not exists courses_level_idx on public.courses (level);
create index if not exists courses_schedule_idx on public.courses (schedule_day, schedule_time_slot);

-- Messaging history support.
create index if not exists messages_sender_idx on public.messages (sender_id);
create index if not exists messages_receiver_idx on public.messages (receiver_id);
create index if not exists messages_created_at_idx on public.messages (created_at);

-- Classroom booking edit/cancel support.
create index if not exists classroom_bookings_date_slot_idx
on public.classroom_bookings (date, time_slot);

create unique index if not exists classroom_bookings_room_date_slot_idx
on public.classroom_bookings (room, date, time_slot);

alter table public.classroom_bookings enable row level security;

-- Remove old conflicting MVP policies if they exist.
drop policy if exists "Authenticated users can update classroom bookings" on public.classroom_bookings;
drop policy if exists "Authenticated users can delete classroom bookings" on public.classroom_bookings;
drop policy if exists "Admins can update classroom bookings" on public.classroom_bookings;
drop policy if exists "Admins can delete classroom bookings" on public.classroom_bookings;
drop policy if exists "Doctors can create course classroom bookings" on public.classroom_bookings;

create policy "Doctors and admins can create course classroom bookings"
on public.classroom_bookings
for insert
to authenticated
with check (
  booked_by = auth.uid()
  and course_id is not null
  and exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role in ('admin', 'professor', 'doctor')
  )
);

create policy "Admins can update classroom bookings"
on public.classroom_bookings
for update
to authenticated
using (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
)
with check (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
);

create policy "Admins can delete classroom bookings"
on public.classroom_bookings
for delete
to authenticated
using (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
);

-- Profile editing support.
alter table public.profiles enable row level security;

drop policy if exists "Users can update own profile" on public.profiles;

create policy "Users can update own profile"
on public.profiles
for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());
