-- Simple forgot-password support for the UMS demo project.
-- Run this file in Supabase SQL Editor.
--
-- Important: this creates a direct password-reset RPC for your project demo.
-- In a production system, use Supabase's email reset link flow instead.

create extension if not exists pgcrypto with schema extensions;

create or replace function public.demo_account_email_exists(user_email text)
returns boolean
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  clean_email text;
  account_exists boolean;
begin
  clean_email := lower(trim(coalesce(user_email, '')));

  if clean_email = '' then
    return false;
  end if;

  select exists (
    select 1
    from auth.users u
    where lower(u.email) = clean_email
  )
  into account_exists;

  return account_exists;
end;
$$;

create or replace function public.demo_reset_password_by_email(
  user_email text,
  new_password text
)
returns boolean
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  clean_email text;
  clean_password text;
begin
  clean_email := lower(trim(coalesce(user_email, '')));
  clean_password := coalesce(new_password, '');

  if clean_email = '' then
    raise exception 'Email is required';
  end if;

  if length(clean_password) < 6 then
    raise exception 'Password must be at least 6 characters';
  end if;

  update auth.users
  set
    encrypted_password = crypt(clean_password, gen_salt('bf')),
    email_confirmed_at = coalesce(email_confirmed_at, now()),
    confirmation_token = '',
    recovery_token = '',
    updated_at = now()
  where lower(email) = clean_email;

  if not found then
    raise exception 'No account was found with this email address';
  end if;

  return true;
end;
$$;

revoke all on function public.demo_account_email_exists(text) from public;
revoke all on function public.demo_reset_password_by_email(text, text) from public;

grant execute on function public.demo_account_email_exists(text) to anon, authenticated;
grant execute on function public.demo_reset_password_by_email(text, text) to anon, authenticated;
